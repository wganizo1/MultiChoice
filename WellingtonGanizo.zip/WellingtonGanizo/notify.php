
<?php
//GET TOCKEN & USER ID
$device_token=$_POST['token'];
$user_id = $_POST['user_id'];
//CONNECT TO DATABASE
mysql_connect('localhost','f4012065_ganizo','Pleasetryagain04!');
mysql_select_db('f4012065_alterbliss_edu'); 
            
//I CREATED A SMALL TABLE IN MY DATABASE CALLED multi_choice
//I WANT TO USE THIS TO STORE THE DEVICE TOKEN AND USE IT TO SEND THE NOTIFICATION

$qry = "UPDATE multi_choice set token = '$device_token' where id = '$user_id'";
mysql_query($qry) or die("Error: ".mysql_error());
$fetch = mysql_query("SELECT * FROM multi_choice where id ='$user_id'");  
          while ($row1 = mysql_fetch_array($fetch, MYSQL_ASSOC)) {
            sendGCM("Please Expand this notification to view the associated custom image",$row1['token'],$row1['nme']);
          }
//CALL TO sendGCM FOR SENDING PUSH NOTIFICATION           
function sendGCM($message, $id,$nme) {

$url = 'https://fcm.googleapis.com/fcm/send';

$fields = array (
        'registration_ids' => array (
                $id
        ),
        'data' => array (
                "message" => $message,
                "image" => "https://alterbliss.co.za/nat_geo.jpg",
                "title" => "Hi ".$nme
        )
);
$fields = json_encode ( $fields );

$headers = array (
        'Authorization: key=' . "AAAANiO7fyw:APA91bGvobWNkJj5vCuNouQt06hc-6pMRHnl5hgmk667KAG1pgYUnl1YAKO2AlnDJTMuulE93WYcHJTwfu4ifnFihx2yLLu4juqXy6cI7K9qwAHrwXF5-NHuvjnEqql_gOFk5xntzh7V",
        'Content-Type: application/json'
);

$ch = curl_init ();
curl_setopt ( $ch, CURLOPT_URL, $url );
curl_setopt ( $ch, CURLOPT_POST, true );
curl_setopt ( $ch, CURLOPT_HTTPHEADER, $headers );
curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt ( $ch, CURLOPT_POSTFIELDS, $fields );

$result = curl_exec ( $ch );
curl_close ( $ch );
}

?>