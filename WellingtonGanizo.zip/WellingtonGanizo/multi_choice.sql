-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 11, 2019 at 10:28 AM
-- Server version: 5.5.34-MariaDB-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `f4012065_alterbliss_edu`
--

-- --------------------------------------------------------

--
-- Table structure for table `multi_choice`
--

CREATE TABLE `multi_choice` (
  `id` int(11) NOT NULL,
  `token` varchar(300) NOT NULL,
  `nme` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `multi_choice`
--

INSERT INTO `multi_choice` (`id`, `token`, `nme`) VALUES
(1, 'fzLggxBsm1A:APA91bH7gIseVr28Uiuurqi7o8k7GLyLd35AH-8BJPpX-mB7IX1pBfEAlZRtwzCcUdA8JKfJaH-Wpm6LgzlsMhJlJuDse3yVSkZZVcu1p9Mq54GNNRyGZtxW8I6ehCmxmcpXAhesjmjS', 'Akshay');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `multi_choice`
--
ALTER TABLE `multi_choice`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `multi_choice`
--
ALTER TABLE `multi_choice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
